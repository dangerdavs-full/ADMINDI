package com.admindi.backend.controller;

import com.admindi.backend.service.MercadoPagoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/integrations/mercadopago")
public class MercadoPagoController {

    private final MercadoPagoService mpService;

    @Autowired
    public MercadoPagoController(MercadoPagoService mpService) {
        this.mpService = mpService;
    }

    /** Tenant requests a Mercado Pago checkout URL */
    @PostMapping("/create-preference")
    @PreAuthorize("hasRole('TENANT')")
    public ResponseEntity<Map<String, String>> createPreference(@RequestBody Map<String, String> payload) {
        String invoiceId = payload.get("invoiceId");
        String tenantEmail = payload.get("tenantEmail");
        if (invoiceId == null) {
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.ok(mpService.createPreference(invoiceId, tenantEmail));
    }

    /** Mercado Pago IPN webhook — NO JWT required, validated by MP signature */
    @PostMapping("/webhook")
    public ResponseEntity<Void> webhook(@RequestBody Map<String, Object> payload) {
        mpService.processWebhook(payload);
        return ResponseEntity.ok().build();
    }

    /** Check payment status for an invoice */
    @GetMapping("/payment-status/{invoiceId}")
    @PreAuthorize("hasAnyRole('TENANT','OWNER') or hasAuthority('PAYMENT_VIEW')")
    public ResponseEntity<Map<String, String>> paymentStatus(@PathVariable String invoiceId) {
        return ResponseEntity.ok(mpService.getPaymentStatus(invoiceId));
    }
}

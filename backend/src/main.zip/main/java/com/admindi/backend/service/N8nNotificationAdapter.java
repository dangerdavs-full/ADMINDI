package com.admindi.backend.service;

import com.admindi.backend.model.AuditEventEntity;
import com.admindi.backend.model.UserEntity;
import com.admindi.backend.repository.AuditEventRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Adapter for outbound notifications to n8n.
 * Feature flag: integrations.n8n.enabled (default: false).
 * 
 * Events:
 * OWNER_CREATED — new owner onboarded
 * OWNER_CONTACT_UPDATED — contact email/phone changed
 * OWNER_DEACTIVATED — owner soft-deleted, stop all comms
 * OWNER_PURGED — owner hard-deleted (clean payload, no user data)
 * PROPERTY_DELETE_REQUESTED — admin requests property deletion
 * PROPERTY_DELETE_APPROVED — owner approves property deletion
 * TENANT_EXPEDIENTE_ARCHIVED — tenant expediente archived
 *
 * Política Etapa 1 / prod: el webhook **nunca** transporta contraseñas temporales, MFA, tokens ni datos de recuperación.
 * Solo metadatos operativos; el audit interno sigue redactando campos sensibles.
 *
 * <p><b>V50 — identidad:</b> el payload publica {@code loginUsername} (no
 * {@code loginEmail}). El email queda sólo como {@code contactEmail} (canal
 * opcional de contacto). Cualquier flujo n8n que todavía leyera {@code loginEmail}
 * debe migrarse a {@code loginUsername}.</p>
 */
@Service
public class N8nNotificationAdapter {

    private static final Logger logger = LoggerFactory.getLogger(N8nNotificationAdapter.class);

    /**
     * Fields that are ALWAYS stripped from any n8n payload before serialization.
     * Defense in depth: if a future caller adds a sensitive field, it gets redacted automatically.
     */
    private static final Set<String> REDACTED_FIELDS = Set.of(
        "password", "tempPassword", "temporaryPassword",
        "mfaSecret", "mfaCode", "totpSecret",
        "recoveryToken", "resetToken",
        "refreshToken", "accessToken", "sessionToken",
        "challengeToken", "bearerToken"
    );

    @Value("${integrations.n8n.enabled:false}")
    private boolean enabled;

    @Value("${integrations.n8n.webhook-url:}")
    private String webhookUrl;

    @Value("${app.url:http://localhost:3000}")
    private String appUrl;

    private final AuditEventRepository auditRepo;

    public N8nNotificationAdapter(AuditEventRepository auditRepo) {
        this.auditRepo = auditRepo;
    }

    // ---- OWNER_CREATED ----

    public void notifyOwnerCreated(UserEntity owner, String tempPassword, String createdBy) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("event", "OWNER_CREATED");
        payload.put("ownerId", owner.getId());
        payload.put("name", owner.getName());
        // V50: loginUsername reemplaza loginEmail — el username es la identidad de login.
        payload.put("loginUsername", owner.getUsername());
        payload.put("contactEmail", owner.getContactEmail());
        payload.put("contactPhone", owner.getContactPhone());
        payload.put("contactCountryCode", owner.getContactCountryCode());
        payload.put("active", owner.isActive());
        payload.put("temporaryPasswordIssued", tempPassword != null && !tempPassword.isBlank());
        payload.put("createdBy", createdBy);
        payload.put("timestamp", LocalDateTime.now().toString());
        payload.put("loginUrl", appUrl + "/login");
        payload.put("appUrl", appUrl);
        // tempPassword solo existe en-app / notificación interna; no se envía a n8n (Etapa 1 — gobierno).

        sendToN8n("OWNER_CREATED", owner.getId(), createdBy, payload);
    }

    // ---- OWNER_CONTACT_UPDATED ----

    public void notifyOwnerContactUpdated(UserEntity owner, String updatedBy) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("event", "OWNER_CONTACT_UPDATED");
        payload.put("ownerId", owner.getId());
        payload.put("name", owner.getName());
        payload.put("loginUsername", owner.getUsername());
        payload.put("contactEmail", owner.getContactEmail());
        payload.put("contactPhone", owner.getContactPhone());
        payload.put("contactCountryCode", owner.getContactCountryCode());
        payload.put("active", owner.isActive());
        payload.put("updatedBy", updatedBy);
        payload.put("timestamp", LocalDateTime.now().toString());

        sendToN8n("OWNER_CONTACT_UPDATED", owner.getId(), updatedBy, payload);
    }

    // ---- OWNER_DEACTIVATED ----

    public void notifyOwnerDeactivated(UserEntity owner, String deactivatedBy, String reason) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("event", "OWNER_DEACTIVATED");
        payload.put("ownerId", owner.getId());
        payload.put("name", owner.getName());
        payload.put("loginUsername", owner.getUsername());
        payload.put("contactEmail", owner.getContactEmail());
        payload.put("contactPhone", owner.getContactPhone());
        payload.put("contactCountryCode", owner.getContactCountryCode());
        payload.put("active", false);
        payload.put("deletedAt",
                owner.getDeletedAt() != null ? owner.getDeletedAt().toString() : LocalDateTime.now().toString());
        payload.put("deletedBy", deactivatedBy);
        payload.put("reason", reason != null ? reason : "Administrative deactivation");
        payload.put("timestamp", LocalDateTime.now().toString());

        sendToN8n("OWNER_DEACTIVATED", owner.getId(), deactivatedBy, payload);
    }

    // ---- OWNER_PURGED ----

    /**
     * Clean notification: owner is already deleted, so we only send IDs and metadata.
     * No user entity data (already gone from DB).
     */
    public void notifyOwnerPurged(String ownerId, String ownerName, String purgedBy, int usersDeleted) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("event", "OWNER_PURGED");
        payload.put("ownerId", ownerId);
        payload.put("ownerName", ownerName);
        payload.put("usersDeleted", usersDeleted);
        payload.put("purgedBy", purgedBy);
        payload.put("timestamp", LocalDateTime.now().toString());

        sendToN8n("OWNER_PURGED", ownerId, purgedBy, payload);
    }

    // ---- PROPERTY_DELETE_REQUESTED ----

    public void notifyPropertyDeleteRequested(String ownerId, String propertyId, String propertyName, String requestedBy) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("event", "PROPERTY_DELETE_REQUESTED");
        payload.put("ownerId", ownerId);
        payload.put("propertyId", propertyId);
        payload.put("propertyName", propertyName);
        payload.put("requestedBy", requestedBy);
        payload.put("timestamp", LocalDateTime.now().toString());

        sendToN8n("PROPERTY_DELETE_REQUESTED", ownerId, requestedBy, payload);
    }

    // ---- PROPERTY_DELETE_APPROVED ----

    public void notifyPropertyDeleteApproved(String ownerId, String propertyId, String propertyName, String approvedBy) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("event", "PROPERTY_DELETE_APPROVED");
        payload.put("ownerId", ownerId);
        payload.put("propertyId", propertyId);
        payload.put("propertyName", propertyName);
        payload.put("approvedBy", approvedBy);
        payload.put("timestamp", LocalDateTime.now().toString());

        sendToN8n("PROPERTY_DELETE_APPROVED", ownerId, approvedBy, payload);
    }

    // ---- TENANT_EXPEDIENTE_ARCHIVED ----

    /**
     * Baja operativa de expediente (DELETE tenant / archive): opcional si integrations.n8n.enabled.
     */
    public void notifyTenantExpedienteArchived(String ownerId, String tenantProfileId, String propertyId,
            String tenantUserId, String actorEmail) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("event", "TENANT_EXPEDIENTE_ARCHIVED");
        payload.put("ownerId", ownerId);
        payload.put("tenantProfileId", tenantProfileId);
        payload.put("propertyId", propertyId != null ? propertyId : "");
        payload.put("tenantUserId", tenantUserId);
        payload.put("actorEmail", actorEmail != null ? actorEmail : "");
        payload.put("timestamp", LocalDateTime.now().toString());
        sendToN8n("TENANT_EXPEDIENTE_ARCHIVED", ownerId, actorEmail != null ? actorEmail : "SYSTEM", payload);
    }

    /**
     * Etapa 2 — evento genérico de "tarea pendiente del dueño".
     * n8n es solo event bus: el workflow en n8n decide cómo construir el mensaje
     * (WhatsApp/email) tipo "entra a tu plataforma, tienes tareas pendientes".
     * La app NO envía texto, plantillas ni detalles sensibles. Solo metadata operativa.
     */
    public void notifyOwnerTaskPending(String ownerId, String taskId, String taskType, String actorEmail) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("event", "OWNER_TASK_PENDING");
        payload.put("ownerId", ownerId);
        payload.put("taskId", taskId != null ? taskId : "");
        payload.put("taskType", taskType != null ? taskType : "");
        payload.put("timestamp", LocalDateTime.now().toString());
        payload.put("loginUrl", appUrl + "/login");
        sendToN8n("OWNER_TASK_PENDING", ownerId, actorEmail != null ? actorEmail : "SYSTEM", payload);
    }

    // ---- Core send logic ----

    private void sendToN8n(String eventName, String ownerId, String actorId, Map<String, Object> payload) {
        // Defense in depth: strip ALL sensitive fields before serialization
        Map<String, Object> safePayload = new LinkedHashMap<>(payload);
        for (String field : REDACTED_FIELDS) {
            safePayload.remove(field);
        }

        String auditPrefix = "N8N_" + eventName;

        if (!enabled) {
            // DEBUG intencional: WhatsApp/Email ahora salen por TwilioWhatsAppService y
            // EmailService respectivamente, y n8n está OFF por defecto. Este log solía
            // confundir a operadores haciéndoles creer que n8n intentaba mandar algo.
            // Solo se eleva a INFO si activas integrations.n8n.enabled=true.
            logger.debug("[N8N] Integration disabled. Skipping {} for owner: {}", eventName, ownerId);
            auditNotification(ownerId, actorId, auditPrefix + "_SKIPPED",
                    "Integration disabled (integrations.n8n.enabled=false)", safePayload);
            return;
        }

        if (webhookUrl == null || webhookUrl.isBlank()) {
            logger.warn("[N8N] Webhook URL not configured. Cannot send {} for owner: {}", eventName, ownerId);
            auditNotification(ownerId, actorId, auditPrefix + "_FAILED",
                    "Webhook URL not configured", safePayload);
            return;
        }

        try {
            var client = java.net.http.HttpClient.newBuilder()
                    .version(java.net.http.HttpClient.Version.HTTP_1_1)
                    .connectTimeout(java.time.Duration.ofSeconds(5))
                    .build();
            var json = new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(safePayload);
            var request = java.net.http.HttpRequest.newBuilder()
                    .uri(java.net.URI.create(webhookUrl))
                    .header("Content-Type", "application/json")
                    .POST(java.net.http.HttpRequest.BodyPublishers.ofString(json))
                    .timeout(java.time.Duration.ofSeconds(10))
                    .build();

            var response = client.send(request, java.net.http.HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() >= 200 && response.statusCode() < 300) {
                logger.info("[N8N] {} sent successfully for owner: {} (HTTP {})", eventName, ownerId,
                        response.statusCode());
                auditNotification(ownerId, actorId, auditPrefix + "_SENT",
                        "HTTP " + response.statusCode(), safePayload);
            } else {
                logger.error("[N8N] {} failed for owner: {} (HTTP {}): {}", eventName, ownerId, response.statusCode(),
                        response.body());
                auditNotification(ownerId, actorId, auditPrefix + "_FAILED",
                        "HTTP " + response.statusCode() + ": " + truncate(response.body(), 200), safePayload);
            }
        } catch (Exception e) {
            logger.error("[N8N] {} error for owner: {}: {}", eventName, ownerId, e.getMessage(), e);
            auditNotification(ownerId, actorId, auditPrefix + "_FAILED",
                    "Exception: " + e.getMessage(), safePayload);
        }
    }

    private void auditNotification(String ownerId, String actorId, String eventType, String detail,
            Map<String, Object> payload) {
        try {
            AuditEventEntity audit = new AuditEventEntity();
            audit.setId(UUID.randomUUID().toString());
            audit.setTimestamp(LocalDateTime.now());
            audit.setActorId(actorId);
            audit.setEventType(eventType);
            audit.setResourceType("Owner");
            audit.setResourceId(ownerId);
            audit.setOwnerId(ownerId);

            // Redact sensitive data (defensa en profundidad — already stripped in sendToN8n but belt+suspenders)
            Map<String, Object> safePayload = new LinkedHashMap<>(payload);
            for (String field : REDACTED_FIELDS) {
                safePayload.remove(field);
            }
            audit.setNewValues(new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(safePayload));
            audit.setOldValues("{\"detail\":\"" + detail.replace("\"", "'") + "\"}");

            auditRepo.save(audit);
        } catch (Exception e) {
            logger.error("[N8N] Failed to save audit for {}: {}", eventType, e.getMessage());
        }
    }

    private String truncate(String s, int max) {
        if (s == null)
            return "";
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }
}

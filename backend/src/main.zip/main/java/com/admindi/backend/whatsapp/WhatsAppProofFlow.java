package com.admindi.backend.whatsapp;

import com.admindi.backend.model.UserEntity;
import com.admindi.backend.model.WhatsappConversationStateEntity;
import com.admindi.backend.service.TwilioWhatsAppService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * Flujo del comprobante SPEI recibido por WhatsApp.
 *
 * Fase 2 (este archivo): stub que almacena la imagen y pide al inquilino
 * que confirme manualmente. El OCR real con Claude Vision se conecta en
 * Fase 3 vía {@code ReceiptOcrService}, inyectado como {@link ObjectProvider}
 * para permitir que el bot funcione aunque Claude esté deshabilitado.
 *
 * El método {@code processIncomingProof} es el punto único de extensión: cuando
 * Fase 3 esté lista, se conecta el servicio OCR sin tocar {@code WhatsAppFlowHandlers}.
 */
@Service
public class WhatsAppProofFlow {

    private static final Logger logger = LoggerFactory.getLogger(WhatsAppProofFlow.class);

    private final WhatsAppSessionService sessions;
    private final TwilioWhatsAppService twilio;
    private final ObjectProvider<ReceiptOcrPort> ocrPortProvider;
    private final ObjectProvider<ProofSubmissionPort> submissionPortProvider;

    @Autowired
    public WhatsAppProofFlow(WhatsAppSessionService sessions,
                              TwilioWhatsAppService twilio,
                              @Qualifier("receiptOcrPort") ObjectProvider<ReceiptOcrPort> ocrPortProvider,
                              @Qualifier("proofSubmissionPort") ObjectProvider<ProofSubmissionPort> submissionPortProvider) {
        this.sessions = sessions;
        this.twilio = twilio;
        this.ocrPortProvider = ocrPortProvider;
        this.submissionPortProvider = submissionPortProvider;
    }

    public void processIncomingProof(String fromE164, UserEntity user,
                                      WhatsappConversationStateEntity session,
                                      String invoiceId,
                                      WhatsAppMediaDownloader.Media media) {
        ReceiptOcrPort ocr = ocrPortProvider.getIfAvailable();
        if (ocr == null) {
            // Fase 2 degraded path: sin OCR configurado, avisamos al usuario y
            // NO creamos proof. Alternativa futura: crear proof sin datos y
            // pedir que los capture el usuario en el portal web.
            twilio.sendFreeformWhatsApp(fromE164,
                    "Recibí tu imagen, pero el sistema de reconocimiento automático no " +
                    "está disponible ahora mismo. Sube el comprobante desde el portal web " +
                    "para que se procese con validación manual.");
            sessions.transition(session, WhatsAppBotState.MENU, Map.of());
            return;
        }

        try {
            ReceiptOcrPort.ExtractedReceipt extracted = ocr.extract(media.bytes(),
                    media.mimeType(), user.getId(), user.getOwnerId());
            if (!extracted.ok()) {
                twilio.sendFreeformWhatsApp(fromE164,
                        "No logré leer el comprobante (" + safe(extracted.errorMessage()) + "). " +
                        "¿Puedes enviarlo de nuevo con mejor luz y enfoque?");
                return;
            }

            sessions.putContext(session, "ocrClaveRastreo", extracted.claveRastreo());
            sessions.putContext(session, "ocrAmount", extracted.amount());
            sessions.putContext(session, "ocrDate", extracted.transferDate());
            sessions.putContext(session, "ocrBankEmitter", extracted.bankEmitter());
            sessions.putContext(session, "ocrAccountReceiver", extracted.accountReceiver());
            sessions.putContext(session, "ocrImagePath", storeProofBytes(media));
            sessions.transition(session, WhatsAppBotState.PROOF_CONFIRMING_DATA, Map.of());

            StringBuilder sb = new StringBuilder();
            sb.append("Esto fue lo que leí del comprobante:\n\n");
            sb.append("• Clave: ").append(nz(extracted.claveRastreo())).append("\n");
            sb.append("• Monto: $").append(nz(extracted.amount())).append("\n");
            sb.append("• Fecha: ").append(nz(extracted.transferDate())).append("\n");
            sb.append("• Banco emisor: ").append(nz(extracted.bankEmitter())).append("\n");
            sb.append("• Cuenta destino: ").append(nz(extracted.accountReceiver())).append("\n\n");
            if (extracted.confidence() < 0.7) {
                sb.append("Algunos datos pueden estar incompletos. ");
            }
            sb.append("¿Está correcto? Responde SI para validar con Banxico o NO para reintentar.");
            twilio.sendFreeformWhatsApp(fromE164, sb.toString());
        } catch (Exception ex) {
            logger.warn("[BOT-PROOF] OCR failed for user={}: {}", user.getId(),
                    ex.getClass().getSimpleName());
            twilio.sendFreeformWhatsApp(fromE164,
                    "Tuvimos un problema procesando tu comprobante. Intenta de nuevo o súbelo desde el portal web.");
        }
    }

    public void processConfirmation(String fromE164, UserEntity user,
                                     WhatsappConversationStateEntity session, String body) {
        String yesno = body == null ? "" : body.trim().toLowerCase();
        if (yesno.startsWith("n")) {
            sessions.transition(session, WhatsAppBotState.PROOF_WAITING_IMAGE, Map.of());
            twilio.sendFreeformWhatsApp(fromE164,
                    "Ok, envíame la foto de nuevo.");
            return;
        }
        if (!yesno.startsWith("s") && !yesno.startsWith("y")) {
            twilio.sendFreeformWhatsApp(fromE164,
                    "Por favor responde SI si los datos son correctos o NO para reintentar.");
            return;
        }

        ProofSubmissionPort submitter = submissionPortProvider.getIfAvailable();
        if (submitter == null) {
            twilio.sendFreeformWhatsApp(fromE164,
                    "El procesador de pagos no está disponible ahora. Intenta más tarde o súbelo desde el portal.");
            sessions.transition(session, WhatsAppBotState.MENU, Map.of());
            return;
        }

        Map<String, Object> ctx = sessions.getContext(session);
        String invoiceId = (String) ctx.get("invoiceId");
        ProofSubmissionPort.SubmissionResult result = submitter.submit(user, invoiceId,
                (String) ctx.get("ocrClaveRastreo"),
                (String) ctx.get("ocrBankEmitter"),
                (String) ctx.get("ocrAccountReceiver"),
                (String) ctx.get("ocrAmount"),
                (String) ctx.get("ocrDate"),
                (String) ctx.get("ocrImagePath"));

        String friendlyMessage = switch (result.status()) {
            case VALIDATED -> "Pago validado automáticamente con Banxico. Tu renta quedó registrada.";
            case INCOMPLETE -> "Faltan datos (" + safe(result.detail()) + "). " +
                    "Repito el proceso desde MENU o sube el comprobante desde el portal para completar.";
            case REJECTED_BY_CEP -> "Banxico rechazó la validación (" + safe(result.detail()) +
                    "). Intenta nuevamente o contacta a tu arrendador.";
            case TEMP_ERROR -> "Registré tu comprobante; el dueño lo revisará manualmente porque " +
                    "la validación automática no está disponible ahora.";
            case FAILED -> "No pude procesar tu comprobante. Intenta desde el portal web.";
        };
        twilio.sendFreeformWhatsApp(fromE164, friendlyMessage + "\n\nEscribe MENU para volver.");
        sessions.transition(session, WhatsAppBotState.MENU, Map.of());
    }

    private String storeProofBytes(WhatsAppMediaDownloader.Media media) {
        // Delegación al storage: guardamos bajo bot-proofs. El path queda en el
        // contexto y lo usa ProofSubmissionPort al crear el TransferProofSubmission.
        try {
            return submissionPortProvider.getIfAvailable() != null
                    ? submissionPortProvider.getObject().persistBotProofImage(media.bytes(), media.mimeType())
                    : null;
        } catch (Exception ex) {
            logger.warn("[BOT-PROOF] store failed: {}", ex.getMessage());
            return null;
        }
    }

    private String nz(Object o) {
        return o == null || o.toString().isBlank() ? "(pendiente)" : o.toString();
    }

    private String safe(String s) {
        if (s == null) return "";
        return s.length() > 160 ? s.substring(0, 160) : s;
    }
}

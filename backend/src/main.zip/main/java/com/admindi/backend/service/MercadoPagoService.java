package com.admindi.backend.service;

import com.admindi.backend.model.*;
import com.admindi.backend.repository.InvoiceRepository;
import com.admindi.backend.repository.PaymentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * Mercado Pago integration service.
 * 
 * V1: Mock implementation with correct contracts.
 * When real credentials are available, replace internal logic
 * without changing the public interface.
 */
@Service
public class MercadoPagoService {

    private static final Logger logger = LoggerFactory.getLogger(MercadoPagoService.class);

    @Value("${mercadopago.access-token:TEST-mock-token}")
    private String accessToken;

    private final InvoiceRepository invoiceRepository;
    private final PaymentRepository paymentRepository;
    private final DomainEventDispatcher dispatcher;
    private final PropertyMovementService propertyMovementService;

    public MercadoPagoService(InvoiceRepository invoiceRepository,
                              PaymentRepository paymentRepository,
                              DomainEventDispatcher dispatcher,
                              PropertyMovementService propertyMovementService) {
        this.invoiceRepository = invoiceRepository;
        this.paymentRepository = paymentRepository;
        this.dispatcher = dispatcher;
        this.propertyMovementService = propertyMovementService;
    }

    /**
     * Create a payment preference (checkout URL) for an invoice.
     * 
     * @return Map with: preferenceId, checkoutUrl, sandboxUrl
     */
    public Map<String, String> createPreference(String invoiceId, String tenantEmail) {
        InvoiceEntity invoice = invoiceRepository.findById(invoiceId)
                .orElseThrow(() -> new RuntimeException("Factura no encontrada."));

        if ("PAID".equals(invoice.getStatus())) {
            throw new RuntimeException("La factura ya está pagada.");
        }

        // --- MOCK: In production, use Mercado Pago SDK ---
        // MercadoPagoConfig.setAccessToken(accessToken);
        // Preference preference = new Preference();
        // preference.setPayer(new Payer().setEmail(tenantEmail));
        // preference.setItems(List.of(item));
        // preference.setBackUrls(backUrls);
        // preference.setAutoReturn("approved");
        // preference.setExternalReference(invoiceId);
        // preference.save();

        String mockPreferenceId = "MOCK-PREF-" + UUID.randomUUID().toString().substring(0, 8);
        String mockCheckoutUrl = "https://www.mercadopago.com.mx/checkout/v1/redirect?pref_id=" + mockPreferenceId;

        logger.info("[MercadoPago] Mock preference created for invoice {}: {}", invoiceId, mockPreferenceId);

        return Map.of(
            "preferenceId", mockPreferenceId,
            "checkoutUrl", mockCheckoutUrl,
            "sandboxUrl", "https://sandbox.mercadopago.com.mx/checkout/v1/redirect?pref_id=" + mockPreferenceId,
            "invoiceId", invoiceId,
            "amount", invoice.getTotalAmount().toPlainString()
        );
    }

    /**
     * Process a webhook notification from Mercado Pago.
     * Called when MP confirms a payment.
     */
    @Transactional
    public void processWebhook(Map<String, Object> payload) {
        String type = payload.get("type") != null ? payload.get("type").toString() : "";
        
        if (!"payment".equals(type)) {
            logger.debug("[MercadoPago] Ignoring webhook type: {}", type);
            return;
        }

        // --- MOCK: In production, fetch payment from MP API ---
        // String paymentId = payload.get("data.id").toString();
        // Payment mpPayment = Payment.findById(paymentId);
        // String invoiceId = mpPayment.getExternalReference();
        // String status = mpPayment.getStatus(); // approved, rejected, etc.

        // For mock: expect invoiceId and status in payload
        String invoiceId = payload.get("external_reference") != null ? payload.get("external_reference").toString() : null;
        String mpStatus = payload.get("status") != null ? payload.get("status").toString() : "approved";
        String mpPaymentId = payload.get("payment_id") != null ? payload.get("payment_id").toString() : "MOCK-PAY-" + UUID.randomUUID().toString().substring(0, 8);

        if (invoiceId == null) {
            logger.warn("[MercadoPago] Webhook missing external_reference");
            return;
        }

        InvoiceEntity invoice = invoiceRepository.findById(invoiceId).orElse(null);
        if (invoice == null) {
            logger.warn("[MercadoPago] Invoice not found for webhook: {}", invoiceId);
            return;
        }

        if ("PAID".equals(invoice.getStatus())) {
            logger.info("[MercadoPago] Invoice {} already paid, ignoring duplicate webhook", invoiceId);
            return;
        }

        if ("approved".equals(mpStatus)) {
            // Create payment record
            PaymentEntity payment = new PaymentEntity();
            payment.setInvoiceId(invoiceId);
            payment.setOwnerId(invoice.getOwnerId());
            payment.setTenantProfileId(invoice.getTenantProfileId());
            payment.setAmount(invoice.getTotalAmount());
            payment.setPaymentMethod(PaymentMethod.MERCADO_PAGO);
            payment.setGatewayReference(mpPaymentId);
            payment.setStatus(PaymentStatus.CONFIRMED);
            payment.setPaidAt(LocalDateTime.now());
            payment.setConfirmedBy("MERCADO_PAGO");
            payment.setConfirmedAt(LocalDateTime.now());
            BigDecimal total = invoice.getTotalAmount() != null ? invoice.getTotalAmount() : invoice.getBaseAmount();
            payment.setAppliedAmount(total);
            payment.setUnappliedAmount(BigDecimal.ZERO);
            paymentRepository.save(payment);

            // Mark invoice paid
            invoice.setStatus("PAID");
            invoice.setPaidDate(LocalDate.now());
            invoice.setPaymentMethod(PaymentMethod.MERCADO_PAGO);
            invoice.setPaymentGatewayRef(mpPaymentId);
            if (invoice.getPaidAmount() == null) {
                invoice.setPaidAmount(BigDecimal.ZERO);
            }
            invoice.setPaidAmount(total);
            invoice.setOutstandingAmount(BigDecimal.ZERO);
            invoice.setSettlementStatus("PAID");
            invoice.setCreditBalance(invoice.getCreditBalance() != null ? invoice.getCreditBalance() : BigDecimal.ZERO);
            invoiceRepository.save(invoice);

            try {
                propertyMovementService.recordPaymentMovement(invoice, payment);
            } catch (Exception ex) {
                logger.warn("[Timeline] MP payment movement skipped: {}", ex.getMessage());
            }

            dispatcher.dispatch("PAYMENT_MP_CONFIRMED",
                    "Pago Mercado Pago confirmado: " + invoice.getMonthYear(),
                    "ID MP: " + mpPaymentId + " | Monto: $" + invoice.getTotalAmount(),
                    invoice.getOwnerId(), "MERCADO_PAGO", null);

            logger.info("[MercadoPago] Payment confirmed for invoice {} (MP ID: {})", invoiceId, mpPaymentId);
        } else {
            logger.info("[MercadoPago] Payment status '{}' for invoice {} — no action taken", mpStatus, invoiceId);
        }
    }

    /**
     * Check if a preference/payment exists for an invoice.
     */
    public Map<String, String> getPaymentStatus(String invoiceId) {
        InvoiceEntity invoice = invoiceRepository.findById(invoiceId)
                .orElseThrow(() -> new RuntimeException("Factura no encontrada."));

        return Map.of(
            "invoiceId", invoiceId,
            "invoiceStatus", invoice.getStatus(),
            "paymentGatewayRef", invoice.getPaymentGatewayRef() != null ? invoice.getPaymentGatewayRef() : "",
            "paid", String.valueOf("PAID".equals(invoice.getStatus()))
        );
    }
}

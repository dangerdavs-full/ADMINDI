package com.admindi.backend.whatsapp;

/**
 * Estados posibles del chatbot de WhatsApp por número de teléfono.
 *
 * Transiciones controladas por {@code WhatsAppBotOrchestrator}. Cada estado
 * asume un tipo específico de entrada del usuario; si la entrada no coincide,
 * el bot muestra ayuda y permanece en el mismo estado.
 */
public enum WhatsAppBotState {

    /** Primera interacción del inquilino — se le pide fijar un NIP 4-6 dígitos. */
    ASKING_PIN_SETUP,

    /** Volvió — se le pide el NIP que configuró previamente. */
    ASKING_PIN,

    /** Menú principal: elige qué hacer. */
    MENU,

    // ─── Flujo comprobante SPEI ───────────────────────────────────────────
    /** Esperando foto del comprobante. */
    PROOF_WAITING_IMAGE,
    /** Esperando que el inquilino confirme los datos que la IA extrajo. */
    PROOF_CONFIRMING_DATA,

    // ─── Flujo ticket mantenimiento ────────────────────────────────────────
    /** Esperando descripción (texto libre) del problema. */
    TICKET_WAITING_DESC,
    /** Esperando selección de urgencia (baja/media/alta/urgente). */
    TICKET_WAITING_URGENCY,
    /** Esperando fotos del problema; LISTO marca el fin. */
    TICKET_WAITING_PHOTOS,
    /** Esperando selección de propiedad cuando el inquilino tiene múltiples expedientes. */
    TICKET_WAITING_PROPERTY,
    /** Confirmación final antes de crear el ticket. */
    TICKET_CONFIRMING,

    // ─── Flujo consultas ──────────────────────────────────────────────────
    /** Mostrando info — el usuario puede volver al menú. */
    QUERY_VIEWING,

    /** Demasiados intentos fallidos de NIP o sesión bloqueada. */
    LOCKED,

    /** Número no vinculado a ningún TENANT — no avanzamos. */
    UNRECOGNIZED
}
